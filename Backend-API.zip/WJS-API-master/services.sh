sudo service redis-server start
sudo service mongodb start
