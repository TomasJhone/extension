const instance = require('./instance')
const profile = require('./profile')

module.exports = {
	instance,
	profile,
}
